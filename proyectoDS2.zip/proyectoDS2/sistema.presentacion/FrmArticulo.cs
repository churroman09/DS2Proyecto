﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using sistema.Entidad;
using sistema.Negocios;

namespace sistema.presentacion
{
    public partial class FrmArticulo : Form
    {
        public FrmArticulo()
        {
            InitializeComponent();
        }

        #region "Metodos Auxiliares"
        //metodo para formatear el data grid view

        
            private void Formato()
        {
            dgvListado.Columns[0].Visible = false;
            dgvListado.Columns[2].Visible = false;

            dgvListado.Columns[0].Width = 100;
            dgvListado.Columns[1].Width = 50;

            dgvListado.Columns[3].Width = 100;
            dgvListado.Columns[3].HeaderText = "Categoría";

            dgvListado.Columns[4].Width = 100;
            dgvListado.Columns[4].HeaderText = "Código";

            dgvListado.Columns[5].Width = 150;

            dgvListado.Columns[6].Width = 100;
            dgvListado.Columns[6].HeaderText = "Precio Venta";

            dgvListado.Columns[7].Width = 60;

            dgvListado.Columns[8].Width = 200;
            dgvListado.Columns[8].HeaderText = "Descripción";

            dgvListado.Columns[9].Width = 100;
            dgvListado.Columns[10].Width = 100;
        }


        
        //fin del metodo formato

        // para limpiar los controles del formulario
        private void Limpiar()
        {
            txtNombre.Clear();
            txtDescripcion.Clear();
            txtBuscar.Clear();
            txtId.Clear();
            txtCodigo.Clear();
            picCodigo.BackgroundImage = null;
            picImagen.BackgroundImage = null;
            txtPrecioVenta.Clear();
            txtImagen.Clear();
            txtStock.Text ="0";
            txtPrecioVenta.Text = "0.00";

            btnInsertar.Visible = true;
            btnActualizar.Visible = false;

            dgvListado.Columns[0].Visible = false;
            btnActivar.Visible = false;
            btnDesactivar.Visible = false;
            btnEliminar.Visible = false;
            chkSeleccionar.Checked = false;
        }

        //metodo para mostrar un mensaje de error
        private void MensajeError(string mensaje)
        {
            MessageBox.Show(mensaje, "Sistema de Ventas", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        //metodo para mostrar un mensaje de confirmacion
        private void MensajeOk(string mensaje)
        {
            MessageBox.Show(mensaje, "Sistema de Ventas", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }


        // listar Los articulos
        private void Listar()
        {
            dgvListado.DataSource = NArticulos.Listar();
            this.Formato();
            this.Limpiar();
            lblTotal.Text = "Total de Registros: " + dgvListado.Rows.Count.ToString();
        }
        //fin del metodo listar

        //buscar las categorias
        private void Buscar(string valor)
        {
            try
            {
                dgvListado.DataSource = NArticulos.Buscar(valor);
                this.Formato();
                lblTotal.Text = "Total de Registros: " + dgvListado.Rows.Count.ToString();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }//fin de buscar

        //insertar categoria
        private void Insertar()
        {
            try
            {
                string respuesta = ""; //aqui vamos a almacenar la respuesta de la funcion insertar
                if (txtNombre.Text == "" || cmbCategoria.Text == string.Empty || txtCodigo.Text == string.Empty || txtPrecioVenta.Text == string.Empty || txtStock.Text == string.Empty)
                {
                    this.MensajeError("ingrese los datos necesarios");
                }
                else
                {
                    respuesta = NArticulos.Insertar(Convert.ToInt32(cmbCategoria.SelectedValue), txtCodigo.Text.Trim(), txtNombre.Text.Trim(), Convert.ToDecimal(txtPrecioVenta.Text.Trim()), Convert.ToInt32(txtStock.Text.Trim()), txtDescripcion.Text, txtImagen.Text);

                    if (respuesta == ("OK"))
                    {
                        this.MensajeOk("Se insertó de forma correcta el registro");
                        this.Listar();
                    }
                    else
                    {
                        this.MensajeError(respuesta);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //metodo para actualizar una categoria
        private void Actualizar()
        {
            try
            {
                string respuesta = "";
                if (txtNombre.Text == "" || cmbCategoria.Text == string.Empty || txtCodigo.Text == string.Empty || txtPrecioVenta.Text == string.Empty || txtStock.Text == string.Empty)
                {
                    this.MensajeError("ingrese un nombre para la categoria");
                }
                else
                {
                    respuesta = NArticulos.Actualizar(
                        Convert.ToInt32(txtId.Text),
                        Convert.ToInt32(cmbCategoria.SelectedValue),
                        txtCodigo.Text.Trim(),
                        txtNombre.Text.Trim(),
                        Convert.ToDecimal(txtPrecioVenta.Text.Trim()),
                        Convert.ToInt32(txtStock.Text.Trim()),
                        txtDescripcion.Text.Trim(),
                        txtImagen.Text.Trim() // Added missing parameter
                    );
                    if (respuesta == "OK")
                    {
                        this.MensajeOk("Se actualizó de forma correcta el registro");
                        this.Listar();
                        this.Limpiar();
                    }
                    else
                    {
                        this.MensajeError(respuesta);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        //fin de actualizar

        //activar categoria

        private void Activar()
        {
            //preguntar si se quiere activar la/s categoria/s con yes or no
            DialogResult resultado = MessageBox.Show("¿Realmente desea activar el/los registro/s seleccionado/s?", "Sistema de Ventas", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (resultado == DialogResult.Yes)
            {
                try
                {
                    int codigo;
                    string respuesta = "";

                    foreach (DataGridViewRow row in dgvListado.Rows)
                    {
                        if (Convert.ToBoolean(row.Cells[0].Value))
                        {
                            codigo = Convert.ToInt32(row.Cells[1].Value);
                            respuesta = NArticulos.Activar(codigo);
                            if (respuesta == "OK")
                            {
                                this.MensajeOk(("Se activó correctamente el registro") + row.Cells[2].Value.ToString());
                            }
                            else
                            {
                                this.MensajeError(respuesta);
                            }
                        }
                    }
                    this.Listar();
                }
                catch (Exception ex)
                {

                    MessageBox.Show(ex.Message);
                }
            }
        }
        //fin de activar
        //desactivar categoria
        private void desactivar()
        {
            //preguntar si se quiere desactivar la/s categoria/s con yes or no
            DialogResult resultado = MessageBox.Show("¿Realmente desea desactivar el/los registro/s seleccionado/s?", "Sistema de Ventas", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (resultado == DialogResult.Yes)
            {
                try
                {
                    int codigo;
                    string respuesta = "";

                    foreach (DataGridViewRow row in dgvListado.Rows)
                    {
                        if (Convert.ToBoolean(row.Cells[0].Value))
                        {
                            codigo = Convert.ToInt32(row.Cells[1].Value);
                            respuesta = NArticulos.Desactivar(codigo);
                            if (respuesta == "OK")
                            {
                                this.MensajeOk(("Se desactivo correctamente el registro") + row.Cells[2].Value.ToString());
                            }
                            else
                            {
                                this.MensajeError(respuesta);
                            }
                        }
                    }
                    this.Listar();
                }
                catch (Exception ex)
                {

                    MessageBox.Show(ex.Message);
                }
            }
        }//fin de desactivar

        //eliminar categoria
        private void eliminar()
        {
            //preguntar si se quiere eliminar la/s categoria/s con yes or no
            DialogResult resultado = MessageBox.Show("¿Realmente desea eliminar el/los registro/s seleccionado/s?", "Sistema de Ventas", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (resultado == DialogResult.Yes)
            {
                try
                {
                    int codigo;
                    string respuesta = "";

                    foreach (DataGridViewRow row in dgvListado.Rows)
                    {
                        if (Convert.ToBoolean(row.Cells[0].Value))
                        {
                            codigo = Convert.ToInt32(row.Cells[1].Value);
                            respuesta = NCategoria.Eliminar(codigo);
                            if (respuesta == "OK")
                            {
                                this.MensajeOk(("Se elimino correctamente el registro") + row.Cells[2].Value.ToString());
                            }
                            else
                            {
                                this.MensajeError(respuesta);
                            }
                        }
                    }
                    this.Listar();
                }
                catch (Exception ex)
                {

                    MessageBox.Show(ex.Message);
                }
            }
        }//fin de eliminar

        private void CategoriaSeleccionar()
        {
            try
            {
                cmbCategoria.DataSource = NArticulos.SeleccionarCategorias();
                cmbCategoria.DisplayMember = "nombre";
                cmbCategoria.ValueMember = "idcategoria";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        #endregion

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            this.Actualizar();
        }

        private void btnInsertar_Click(object sender, EventArgs e)
        {
            this.Insertar();
        }

        private void btnActivar_Click(object sender, EventArgs e)
        {
            this.Activar();
        }

        private void btnDesactivar_Click(object sender, EventArgs e)
        {
            this.desactivar();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            this.eliminar();
        }

        private void chkSeleccionar_CheckedChanged(object sender, EventArgs e)
        {
            if (chkSeleccionar.Checked)
            {
                dgvListado.Columns[0].Visible = true;
                btnEliminar.Visible = true;
                btnDesactivar.Visible = true;
                btnActivar.Visible = true;
            }
            else
            {
                dgvListado.Columns[0].Visible = false;
                btnEliminar.Visible = false;
                btnDesactivar.Visible = false;
                btnActivar.Visible = false;
            }
        }

        private void dgvListado_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == dgvListado.Columns["Seleccionar"].Index)
            {
                DataGridViewCheckBoxCell ChkEliminar = (DataGridViewCheckBoxCell)dgvListado.Rows[e.RowIndex].Cells["Seleccionar"];
                ChkEliminar.Value = !Convert.ToBoolean(ChkEliminar.Value);
            }
        }

        private void FrmArticulo_Load(object sender, EventArgs e)
        {
            this.Listar();
            this.CategoriaSeleccionar();
        }

        private void dgvListado_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                this.Limpiar();
                btnActualizar.Visible = true;
                btnInsertar.Visible = false;

                txtId.Text = dgvListado.CurrentRow.Cells["ID"].Value.ToString();
                cmbCategoria.SelectedValue = dgvListado.CurrentRow.Cells["idcategoria"].Value.ToString();
                txtCodigo.Text = dgvListado.CurrentRow.Cells["codigo"].Value.ToString();
                txtNombre.Text = dgvListado.CurrentRow.Cells["nombre"].Value.ToString();
                txtPrecioVenta.Text = dgvListado.CurrentRow.Cells["precio_venta"].Value.ToString();
                txtStock.Text = dgvListado.CurrentRow.Cells["Stock"].Value.ToString();
                txtDescripcion.Text = dgvListado.CurrentRow.Cells["Descripcion"].Value.ToString();
                txtImagen.Text = dgvListado.CurrentRow.Cells["Imagen"].Value.ToString();

                tabPrincipal.SelectedIndex = 1;



            }
            catch (Exception ex)
            {

                throw ex;
            }
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Limpiar();
        }
    }
}
