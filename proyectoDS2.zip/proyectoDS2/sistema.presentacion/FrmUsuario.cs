﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sistema.presentacion
{
    public partial class FrmUsuario : Form
    {
        public FrmUsuario()
        {
            InitializeComponent();

        }

        //metodo para formatear la tabla
        private void Formato()
        {
            dgvListado.Columns[0].Visible = false;
            dgvListado.Columns[1].Width = 100;
            dgvListado.Columns[2].Width = 200;
            dgvListado.Columns[3].Width = 100;
            dgvListado.Columns[4].Width = 100;
            dgvListado.Columns[5].Width = 100;
            dgvListado.Columns[6].Width = 100;
            dgvListado.Columns[7].Width = 100;
            dgvListado.Columns[8].Width = 100;
        }
        //metodo limpiar
        private void Limpiar()
        {
            btnInsertar.Visible = true;
            btnActualizar.Visible = false;

            dgvListado.Columns[0].Visible = false;
            btnActivar.Visible = false;
            btnDesactivar.Visible = false;
            btnEliminar.Visible = false;

            txtNombre.Text = string.Empty;
            txtNumeroDocumento.Text = string.Empty;
            txtDireccion.Text = string.Empty;
            txtTelefono.Text = string.Empty;
            txtEmail.Text = string.Empty;
            txtClave.Text = string.Empty;
        }


        //metodo para mostrar un mensaje de error
        private void MensajeError(string mensaje)
        {
            MessageBox.Show(mensaje, "Sistema de Ventas", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        //metodo para mostrar un mensaje de confirmacion
        private void MensajeOk(string mensaje)
        {
            MessageBox.Show(mensaje, "Sistema de Ventas", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        //metodo listar
        private void Listar()
        {
            try
            {
                //establecemos la fuente de datos a mostrar
                dgvListado.DataSource = Negocios.NUsuario.Listar();

                this.Limpiar();
                lblTotal.Text = "Total de Registros: " + Convert.ToString(dgvListado.Rows.Count);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }
        }

        //metodo buscar
        private void Buscar()
        {
            try
            {
                //establecemos la fuente de datos a mostrar
                dgvListado.DataSource = Negocios.NUsuario.Buscar(txtBuscar.Text);
                lblTotal.Text = "Total de Registros: " + Convert.ToString(dgvListado.Rows.Count);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }
        }

        //metodo insertar
        private void Insertar()
        {
            try
            {
                string respuesta = "";
                if (txtNombre.Text == string.Empty || txtEmail.Text == string.Empty || txtClave.Text == string.Empty)
                {
                    this.MensajeError("Falta ingresar algunos datos, serán remarcados");

                }
                else
                {
                    respuesta = Negocios.NUsuario.Insertar(Convert.ToInt32(cmbRol.SelectedValue), txtNombre.Text.Trim(), cmbTipoDocumento.Text, txtNumeroDocumento.Text.Trim(),
                                                            txtDireccion.Text.Trim(), txtTelefono.Text.Trim(), txtEmail.Text.Trim(), txtClave.Text.Trim());
                    if (respuesta.Equals("OK"))
                    {
                        this.MensajeOk("Se insertó de forma correcta el registro");
                        this.Listar();
                    }
                    else
                    {
                        this.MensajeError(respuesta);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }
        }
        //metodo actualizar
        private void Actualizar()
        {
            try
            {
                string respuesta = "";
                if (txtNombre.Text == string.Empty || txtEmail.Text == string.Empty || txtClave.Text == string.Empty || txtId.Text == string.Empty)
                {
                    this.MensajeError("Falta ingresar algunos datos, serán remarcados");
                }
                else
                {
                    respuesta = Negocios.NUsuario.Actualizar(Convert.ToInt32(txtId.Text), Convert.ToInt32(cmbRol.SelectedValue), txtNombre.Text.Trim(), cmbTipoDocumento.Text, txtNumeroDocumento.Text.Trim(),
                                                            txtDireccion.Text.Trim(), txtTelefono.Text.Trim(), txtEmail.Text.Trim(), txtClave.Text.Trim());
                    if (respuesta.Equals("OK"))
                    {
                        this.MensajeOk("Se actualizó de forma correcta el registro");
                        this.Listar();
                    }
                    else
                    {
                        this.MensajeError(respuesta);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }
        }

        //metodo eliminar
        private void Eliminar()
        {
            try
            {
                string respuesta = "";
                if (txtId.Text == string.Empty)
                {
                    this.MensajeError("Seleccione un registro");
                }
                else
                {
                    respuesta = Negocios.NUsuario.Eliminar(Convert.ToInt32(txtId.Text));
                    if (respuesta.Equals("OK"))
                    {
                        this.MensajeOk("Se eliminó de forma correcta el registro");
                        this.Listar();
                    }
                    else
                    {
                        this.MensajeError(respuesta);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }
        }
        //metodo activar
        private void Activar()
        {
            try
            {
                string respuesta = "";
                if (txtId.Text == string.Empty)
                {
                    this.MensajeError("Seleccione un registro");
                }
                else
                {
                    respuesta = Negocios.NUsuario.Activar(Convert.ToInt32(txtId.Text));
                    if (respuesta.Equals("OK"))
                    {
                        this.MensajeOk("Se activó de forma correcta el registro");
                        this.Listar();
                    }
                    else
                    {
                        this.MensajeError(respuesta);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }
        }
        //metodo desactivar
        private void Desactivar()
        {
            try
            {
                string respuesta = "";
                if (txtId.Text == string.Empty)
                {
                    this.MensajeError("Seleccione un registro");
                }
                else
                {
                    respuesta = Negocios.NUsuario.Desactivar(Convert.ToInt32(txtId.Text));
                    if (respuesta.Equals("OK"))
                    {
                        this.MensajeOk("Se desactivó de forma correcta el registro");
                        this.Listar();
                    }
                    else
                    {
                        this.MensajeError(respuesta);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message + ex.StackTrace);
            }
        }
        //metodo para seleccionar
        private void dgvListado_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == dgvListado.Columns["Seleccionar"].Index)
            {
                DataGridViewCheckBoxCell ChkEliminar = (DataGridViewCheckBoxCell)dgvListado.Rows[e.RowIndex].Cells["Seleccionar"];
                ChkEliminar.Value = !Convert.ToBoolean(ChkEliminar.Value);
            }
        }

        // metodo para cargar los roles
        private void CargarRoles()
        {
            cmbRol.DataSource = Negocios.NRol.Listar();
            cmbRol.ValueMember = "idrol";
            cmbRol.DisplayMember = "nombre";
        }

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            this.Buscar();
        }

        private void btnInsertar_Click(object sender, EventArgs e)
        {
            this.Insertar();
        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            this.Actualizar();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Limpiar();

        }



        private void FrmUsuario_Load(object sender, EventArgs e)
        {
            
                this.Listar();
                this.CargarRoles();
            
            
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void btnBuscar_Click_1(object sender, EventArgs e)
        {

        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            this.Eliminar();
        }

        private void btnDesactivar_Click(object sender, EventArgs e)
        {
            this.Desactivar();
        }

        private void btnActivar_Click(object sender, EventArgs e)
        {
            this.Activar();
        }

        private void dgvListado_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                this.Limpiar();
                btnActualizar.Visible = true;
                btnInsertar.Visible = false;
                txtId.Text = Convert.ToString(dgvListado.CurrentRow.Cells["idUsuario"].Value);
                cmbRol.SelectedValue = Convert.ToString(dgvListado.CurrentRow.Cells["idRol"].Value);
                txtNombre.Text = Convert.ToString(dgvListado.CurrentRow.Cells["nombre"].Value);
                cmbTipoDocumento.Text = Convert.ToString(dgvListado.CurrentRow.Cells["tipoDocumento"].Value);
                txtNumeroDocumento.Text = Convert.ToString(dgvListado.CurrentRow.Cells["numDocumento"].Value);
                txtDireccion.Text = Convert.ToString(dgvListado.CurrentRow.Cells["direccion"].Value);
                txtTelefono.Text = Convert.ToString(dgvListado.CurrentRow.Cells["telefono"].Value);
                txtEmail.Text = Convert.ToString(dgvListado.CurrentRow.Cells["email"].Value);
                txtClave.Text = Convert.ToString(dgvListado.CurrentRow.Cells["clave"].Value);
                tabPrincipal.SelectedIndex = 1;
            }
            catch (Exception ex)
            {
                MessageBox.Show("Seleccione desde la celda nombre." + ex.Message);
            }
        }

        private void chkSeleccionar_CheckedChanged(object sender, EventArgs e)
        {
            if (chkSeleccionar.Checked)
            {
                dgvListado.Columns[0].Visible = true;
                btnEliminar.Visible = true;
                btnDesactivar.Visible = true;
                btnActivar.Visible = true;
            }
            else
            {
                dgvListado.Columns[0].Visible = false;
                btnEliminar.Visible = false;
                btnDesactivar.Visible = false;
                btnActivar.Visible = false;
            }
        }
    }
}
