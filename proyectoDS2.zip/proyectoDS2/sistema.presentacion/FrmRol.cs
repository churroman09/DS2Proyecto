﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using sistema.Negocios;

namespace sistema.presentacion
{
    public partial class FrmRol : Form
    {
        public FrmRol()
        {
            InitializeComponent();
        }

        private void Formato()
        {
            dgvListado.Columns[0].Width = 100;
            dgvListado.Columns[1].Width = 290;
            

        }
        private void Listar()
        {
            dgvListado.DataSource = NRol.Listar();
            this.Formato();
      
            lblTotal.Text = "Total de Registros: " + dgvListado.Rows.Count.ToString();
        }

        private void FrmRol_Load(object sender, EventArgs e)
        {
            this.Listar();
        }
    }
}
