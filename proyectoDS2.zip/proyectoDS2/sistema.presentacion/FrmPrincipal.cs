﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sistema.presentacion
{
    public partial class FrmPrincipal : Form
    {
        private int childFormNumber = 0;

        public int IdUsuario { get; set; }
        public int IdRol { get; set; }
        public string Nombre { get; set; }
        public string Rol { get; set; }

        public bool Estado { get; set; }

        public FrmPrincipal()
        {
            InitializeComponent();
        }

        private void ShowNewForm(object sender, EventArgs e)
        {
            Form childForm = new Form();
            childForm.MdiParent = this;
            childForm.Text = "Window " + childFormNumber++;
            childForm.Show();
        }

        private void OpenFile(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            openFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            if (openFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                string FileName = openFileDialog.FileName;
            }
        }

        private void SaveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            saveFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            if (saveFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                string FileName = saveFileDialog.FileName;
            }
        }

        private void ExitToolsStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void CutToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void CopyToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void PasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void ToolBarToolStripMenuItem_Click(object sender, EventArgs e)
        {
           
        }

        private void StatusBarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            statusStrip.Visible = statusBarToolStripMenuItem.Checked;
        }

        private void CascadeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.Cascade);
        }

        private void TileVerticalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileVertical);
        }

        private void TileHorizontalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileHorizontal);
        }

        private void ArrangeIconsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.ArrangeIcons);
        }

        private void CloseAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (Form childForm in MdiChildren)
            {
                childForm.Close();
            }
        }

        private void articulosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmArticulo frm = new FrmArticulo();
            frm.MdiParent = this;
            frm.Show();
        }

        private void categoriasToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmCategorias frm = new FrmCategorias();
            frm.MdiParent = this;
            frm.Show();
        }

        private void rolesToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmRol frm = new FrmRol();
            frm.MdiParent = this;
            frm.Show();
        }

        private void usuariosToolStripMenuItem_Click(object sender, EventArgs e)
        {
            FrmUsuario frm = new FrmUsuario();
            frm.MdiParent = this;
            frm.Show();
        }

        private void FrmPrincipal_FormClosing(object sender, FormClosingEventArgs e)
        {
            Application.Exit();
        }

        private void salirToolStripMenuItem_Click(object sender, EventArgs e)
        {
            DialogResult opcion = MessageBox.Show("Realmente desea salir del sistema?", "Sistema de Ventas", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (opcion == DialogResult.Yes) Application.Exit();
            else return;
        }

        private void FrmPrincipal_Load(object sender, EventArgs e)
        {
            // bienvenida personalizada con messagebox
            MessageBox.Show("Bienvenido(a) " + this.Nombre + " al Sistema de Ventas", "Sistema de Ventas", MessageBoxButtons.OK, MessageBoxIcon.Information);
            toolStripStatusLabel.Text = "Usuario: " + this.Nombre;

            if (Rol == "Administrador")
            {
                almacenToolStripMenuItem.Enabled = true;
                ingresosToolStripMenuItem.Enabled = true;
                comprasToolStripMenuItem.Enabled = true;
                ventasToolStripMenuItem.Enabled = true;
                accesosToolStripMenuItem.Enabled = true;
                consultasToolStripMenuItem.Enabled = true;
                
            }
            else if (Rol == "Vendedor")
            {
                almacenToolStripMenuItem.Enabled = false;
                ingresosToolStripMenuItem.Enabled = false;
                comprasToolStripMenuItem.Enabled = false;
                ventasToolStripMenuItem.Enabled = true;
                accesosToolStripMenuItem.Enabled = false;
                consultasToolStripMenuItem.Enabled = true;
            }
            else if (Rol =="Almacen")
            {
                almacenToolStripMenuItem.Enabled = true;
                ingresosToolStripMenuItem.Enabled = true;
                comprasToolStripMenuItem.Enabled = true;
                ventasToolStripMenuItem.Enabled = false;
                accesosToolStripMenuItem.Enabled = false;
                consultasToolStripMenuItem.Enabled = false;
            }
            //else
            //{
            //    almacenToolStripMenuItem.Enabled = false;
            //    ingresosToolStripMenuItem.Enabled = false;
            //    comprasToolStripMenuItem.Enabled = false;
            //    ventasToolStripMenuItem.Enabled = false;
            //    accesosToolStripMenuItem.Enabled = false;
            //    consultasToolStripMenuItem.Enabled = false;
            //}
        }
    }
}
