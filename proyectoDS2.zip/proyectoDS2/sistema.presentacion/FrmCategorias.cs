﻿using System;
using sistema.Entidad;
using sistema.Negocios;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace sistema.presentacion
{
    public partial class FrmCategorias : Form
    {
        public FrmCategorias()
        {
            InitializeComponent();
        }

        #region "Metodos Auxiliares"
        //metodo para formatear el data grid view

        private void Formato()
        {
            dgvListado.Columns[0].Visible = false;//oculta la columna que se llama seleccionar
            dgvListado.Columns[1].Visible = false;
            dgvListado.Columns[2].Width = 150;//nombre de la categoria
            dgvListado.Columns[3].Width = 400;
            dgvListado.Columns[3].HeaderText = "Descripción";
            dgvListado.Columns[4].Width = 100;
            
        }
        //fin del metodo formato

        // para limpiar los controles del formulario
        private void Limpiar()
        {
            txtNombre.Clear();
            txtDescripcion.Clear();
            txtBuscar.Clear();
            txtId.Clear();

            btnInsertar.Visible = true;
            btnActualizar.Visible = false;

            dgvListado.Columns[0].Visible = false;
            btnActivar.Visible = false;
            btnDesactivar.Visible = false;
            btnEliminar.Visible = false;
            chkSeleccionar.Checked = false;
        }

        //metodo para mostrar un mensaje de error
        private void MensajeError(string mensaje)
        {
            MessageBox.Show(mensaje, "Sistema de Ventas", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        //metodo para mostrar un mensaje de confirmacion
        private void MensajeOk(string mensaje)
        {
            MessageBox.Show(mensaje, "Sistema de Ventas", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }


        // listar Las categorias
        private void Listar()
        {
            dgvListado.DataSource = NCategoria.Listar();
            this.Formato();
            this.Limpiar();
            lblTotal.Text = "Total de Registros: " + dgvListado.Rows.Count.ToString();
        }
        //fin del metodo listar

        //buscar las categorias
        private void Buscar(string valor)
        {
            try
            {
                dgvListado.DataSource = NCategoria.Buscar(valor);
                this.Formato();
                lblTotal.Text = "Total de Registros: " + dgvListado.Rows.Count.ToString();
            }
            catch (Exception ex)
            {

                MessageBox.Show(ex.Message);
            }
        }//fin de buscar

        //insertar categoria
        private void Insertar()
        {
            try
            {
                string respuesta = ""; //aqui vamos a almacenar la respuesta de la funcion insertar
                if (txtNombre.Text == "")
                {
                    this.MensajeError("ingrese un nombre para la categoria");
                }
                else
                {
                    respuesta = NCategoria.Insertar(txtNombre.Text.Trim(), txtDescripcion.Text.Trim());
                    if (respuesta == ("OK"))
                    {
                        this.MensajeOk("Se insertó de forma correcta el registro");
                        this.Listar();
                        
                    }
                    else
                    {
                        this.MensajeError(respuesta);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }//fin de insertar

        //metodo para actualizar una categoria
        private void Actualizar()
        {
            try
            {
                string respuesta = "";
                if (txtNombre.Text == "" || txtId.Text == "")
                {
                    this.MensajeError("ingrese un nombre para la categoria");
                    
                }
                else
                {
                    respuesta = NCategoria.Actualizar(Convert.ToInt32(txtId.Text), txtNombre.Text.Trim(), txtDescripcion.Text.Trim());
                    if (respuesta == "OK")
                    {
                        this.MensajeOk("Se actualizó de forma correcta el registro");
                        this.Listar();
                        this.Limpiar();
                    }
                    else
                    {
                        this.MensajeError(respuesta);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }//fin de actualizar

        //activar categoria
        
        private void Activar() 
        {
            //preguntar si se quiere activar la/s categoria/s con yes or no
         DialogResult resultado = MessageBox.Show("¿Realmente desea activar el/los registro/s seleccionado/s?", "Sistema de Ventas", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (resultado == DialogResult.Yes)
            {
                try
                {
                    int codigo;
                    string respuesta = "";

                    foreach (DataGridViewRow row in dgvListado.Rows)
                    {
                        if (Convert.ToBoolean(row.Cells[0].Value))
                        {
                            codigo = Convert.ToInt32(row.Cells[1].Value);
                            respuesta = NCategoria.Activar(codigo);
                            if (respuesta == "OK")
                            {
                                this.MensajeOk(("Se activó correctamente el registro") + row.Cells[2].Value.ToString());
                            }
                            else
                            {
                                this.MensajeError(respuesta);
                            }
                        }
                    }this.Listar();
                }
                catch (Exception ex)
                {

                    MessageBox.Show(ex.Message);
                }
            }
        }
        //fin de activar
        //desactivar categoria
        private void desactivar()
        {
            //preguntar si se quiere desactivar la/s categoria/s con yes or no
            DialogResult resultado = MessageBox.Show("¿Realmente desea desactivar el/los registro/s seleccionado/s?", "Sistema de Ventas", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (resultado == DialogResult.Yes)
            {
                try
                {
                    int codigo;
                    string respuesta = "";

                    foreach (DataGridViewRow row in dgvListado.Rows)
                    {
                        if (Convert.ToBoolean(row.Cells[0].Value))
                        {
                            codigo = Convert.ToInt32(row.Cells[1].Value);
                            respuesta = NCategoria.Desactivar(codigo);
                            if (respuesta == "OK")
                            {
                                this.MensajeOk(("Se desactivo correctamente el registro") + row.Cells[2].Value.ToString());
                            }
                            else
                            {
                                this.MensajeError(respuesta);
                            }
                        }
                    }
                    this.Listar();
                }
                catch (Exception ex)
                {

                    MessageBox.Show(ex.Message);
                }
            }
        }//fin de desactivar

        //eliminar categoria
        private void eliminar()
        {
            //preguntar si se quiere eliminar la/s categoria/s con yes or no
            DialogResult resultado = MessageBox.Show("¿Realmente desea eliminar el/los registro/s seleccionado/s?", "Sistema de Ventas", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            if (resultado == DialogResult.Yes)
            {
                try
                {
                    int codigo;
                    string respuesta = "";

                    foreach (DataGridViewRow row in dgvListado.Rows)
                    {
                        if (Convert.ToBoolean(row.Cells[0].Value))
                        {
                            codigo = Convert.ToInt32(row.Cells[1].Value);
                            respuesta = NCategoria.Eliminar(codigo);
                            if (respuesta == "OK")
                            {
                                this.MensajeOk(("Se elimino correctamente el registro") + row.Cells[2].Value.ToString());
                            }
                            else
                            {
                                this.MensajeError(respuesta);
                            }
                        }
                    }
                    this.Listar();
                }
                catch (Exception ex)
                {

                    MessageBox.Show(ex.Message);
                }
            }
        }//fin de eliminar
        #endregion

        private void btnBuscar_Click(object sender, EventArgs e)
        {
            this.Buscar(txtBuscar.Text.Trim());//trim elimina los espacios en blanco
        }

        private void FrmCategorias_Load(object sender, EventArgs e)
        {
            this.Listar();
        }

        private void btnInsertar_Click(object sender, EventArgs e)
        {
            this.Insertar();
        }

        private void btnActualizar_Click(object sender, EventArgs e)
        {
            this.Actualizar();
        }

        private void dgvListado_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                this.Limpiar();
                //obtener la informacion de la categoria en la que se hizo el doble click
                txtId.Text = dgvListado.CurrentRow.Cells["ID"].Value.ToString();
                txtNombre.Text = dgvListado.CurrentRow.Cells["Nombre"].Value.ToString();
                txtDescripcion.Text = dgvListado.CurrentRow.Cells["Descripcion"].Value.ToString();
                //mostrar el boton actualizar
                btnActualizar.Visible = true;
                btnInsertar.Visible = false;
                //nos movemos a la pestaña de mantenimiento
                tabPrincipal.SelectedIndex = 1;
            }
            catch (Exception)
            {

                throw;
            }
        }

        private void chkSeleccionar_CheckedChanged(object sender, EventArgs e)
        {
            if (chkSeleccionar.Checked)
            {
                dgvListado.Columns[0].Visible = true;
                btnEliminar.Visible = true;
                btnDesactivar.Visible = true;
                btnActivar.Visible = true;
            }
            else
            {
                dgvListado.Columns[0].Visible = false;
                btnEliminar.Visible = false;
                btnDesactivar.Visible = false;
                btnActivar.Visible = false;
            }
        }

        private void dgvListado_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {
            if (e.ColumnIndex == dgvListado.Columns["Seleccionar"].Index)
            {
                DataGridViewCheckBoxCell ChkEliminar = (DataGridViewCheckBoxCell)dgvListado.Rows[e.RowIndex].Cells["Seleccionar"];
                ChkEliminar.Value = !Convert.ToBoolean(ChkEliminar.Value);
            }
        }

        private void btnActivar_Click(object sender, EventArgs e)
        {
            this.Activar();
        }

        private void btnDesactivar_Click(object sender, EventArgs e)
        {
            this.desactivar();
        }

        private void btnEliminar_Click(object sender, EventArgs e)
        {
            this.eliminar();
        }

        private void btnCancelar_Click(object sender, EventArgs e)
        {
            this.Limpiar();
        }
    }
}
