﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using sistema.Datos;

namespace sistema.Negocios
{
    public class NRol
    {
        public static DataTable Listar()
        {
            //instanciamos la clase categoria
            dRol datos = new dRol();
            return datos.Listar();
        }//fin listar
    }
}
