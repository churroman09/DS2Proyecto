﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using sistema.Datos;
using sistema.Entidad;

namespace sistema.Negocios
{
    public class NArticulos
    {
        // Método para listar artículos
        public static DataTable Listar()
        {
            // Instanciamos la clase dArticulos
            dArticulos datos = new dArticulos();
            return datos.Listar();
        } // Fin Listar

        // Método para buscar artículos
        public static DataTable Buscar(string valor)
        {
            // Instanciamos la clase dArticulos
            dArticulos datos = new dArticulos();
            return datos.Buscar(valor);
        } // Fin Buscar

        // Método para insertar un artículo
        public static string Insertar(int idCategoria, string codigo, string nombre, decimal precioVenta, int stock, string descripcion, string imagen)
        {
            // Instanciamos la clase dArticulos
            dArticulos datos = new dArticulos();
            Articulo articulo = new Articulo
            {
                IdCategoria = idCategoria,
                Codigo = codigo,
                Nombre = nombre,
                PrecioVenta = precioVenta,
                Stock = stock,
                Descripcion = descripcion,
                Imagen = imagen
            };
            return datos.Insertar(articulo);
        } // Fin Insertar

        // Método para actualizar un artículo
        public static string Actualizar(int idArticulo, int idCategoria, string codigo, string nombre, decimal precioVenta, int stock, string descripcion, string imagen)
        {
            // Instanciamos la clase dArticulos
            dArticulos datos = new dArticulos();
            Articulo articulo = new Articulo
            {
                IdArticulo = idArticulo,
                IdCategoria = idCategoria,
                Codigo = codigo,
                Nombre = nombre,
                PrecioVenta = precioVenta,
                Stock = stock,
                Descripcion = descripcion,
                Imagen = imagen
            };
            return datos.Actualizar(articulo);
        } // Fin Actualizar

        // Método para eliminar un artículo
        public static string Eliminar(int idArticulo)
        {
            // Instanciamos la clase dArticulos
            dArticulos datos = new dArticulos();
            return datos.Eliminar(idArticulo);
        } // Fin Eliminar

        // Método para desactivar un artículo
        public static string Desactivar(int idArticulo)
        {
            // Instanciamos la clase dArticulos
            dArticulos datos = new dArticulos();
            return datos.Desactivar(idArticulo);
        } // Fin Desactivar

        // Método para activar un artículo
        public static string Activar(int idArticulo)
        {
            // Instanciamos la clase dArticulos
            dArticulos datos = new dArticulos();
            return datos.Activar(idArticulo);
        } // Fin Activar

        // Método para verificar si un artículo existe
        public static bool Existe(string valor)
        {
            // Instanciamos la clase dArticulos
            dArticulos datos = new dArticulos();
            return datos.Existe(valor);
        } // Fin Existe

        // Método para seleccionar categorías activas
        // Método para seleccionar categorías activas
        public static DataTable SeleccionarCategorias()
        {
            // Instanciamos la clase dArticulos
            dArticulos datos = new dArticulos();
            return datos.SeleccionarCategorias();
        } // Fin SeleccionarCategorias

    }
}

