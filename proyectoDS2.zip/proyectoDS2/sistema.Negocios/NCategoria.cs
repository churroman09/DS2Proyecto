﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using sistema.Datos;
using sistema.Entidad;

namespace sistema.Negocios
{
    public class NCategoria
    {
        //listar categoria
        public static DataTable Listar()
        {
            //instanciamos la clase categoria
            dCategorias datos= new dCategorias();
            return datos.Listar();
        }//fin listar

        public static DataTable Buscar(string valor)
        {
            //instanciamos la clase categoria
            dCategorias datos = new dCategorias();
            return datos.Buscar(valor);
        }//fin buscar

        public static string Insertar(string nombre, string descripcion)
        {
            //instanciamos la clase categoria
            dCategorias datos = new dCategorias();
            Categoria categoria = new Categoria();
            categoria.Nombre = nombre;
           categoria.Descripcion = descripcion;
            return datos.Insertar(categoria);
        }//fin insertar

        public static string Actualizar(int id, string nombre, string descripcion)
        {
            //instanciamos la clase categoria
            dCategorias datos = new dCategorias();
            Categoria categoria = new Categoria();
            categoria.IdCategoria = id;
            categoria.Nombre = nombre;
            categoria.Descripcion = descripcion;
            return datos.Actualizar(categoria);
        }//fin actualizar

        //eliminar una categoria
        public static string Eliminar(int id)
        {
            //instanciamos la clase categoria
            dCategorias datos = new dCategorias();
            return datos.Eliminar(id);
        }//fin eliminar

        //activar una categoria
        public static string Activar(int id)
        {
            //instanciamos la clase categoria
            dCategorias datos = new dCategorias();
            return datos.Activar(id);
        }//fin activar

        //desactivar una categoria
        public static string Desactivar(int id)
        {
            //instanciamos la clase categoria
            dCategorias datos = new dCategorias();
            return datos.Desactivar(id);
        }//fin desactivar
    }

}
