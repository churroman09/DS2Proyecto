﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using sistema.Datos;
using sistema.Entidad;

namespace sistema.Negocios
{
    public class NUsuario
    {
        // Listar usuarios
        public static DataTable Listar()
        {
            dUsuario datos = new dUsuario();
            return datos.Listar();
        }// fin listar

        // Buscar usuario por nombre o email
        public static DataTable Buscar(string valor)
        {
            dUsuario datos = new dUsuario();
            return datos.Buscar(valor);
        }// fin buscar

        // Insertar un nuevo usuario
        public static string Insertar(int idRol, string nombre, string tipoDocumento, string numDocumento,
                                      string direccion, string telefono, string email, string clave)
        {
            dUsuario datos = new dUsuario();
            Usuario usuario = new Usuario
            {
                IdRol = idRol,
                Nombre = nombre,
                TipoDocumento = tipoDocumento,
                NumDocumento = numDocumento,
                Direccion = direccion,
                Telefono = telefono,
                Email = email,
                Clave = clave
            };

            return datos.Insertar(usuario);
        }// fin insertar

        // Actualizar un usuario
        public static string Actualizar(int idUsuario, int idRol, string nombre, string tipoDocumento,
                                        string numDocumento, string direccion, string telefono, string email, string clave)
        {
            dUsuario datos = new dUsuario();
            Usuario usuario = new Usuario
            {
                IdUsuario = idUsuario,
                IdRol = idRol,
                Nombre = nombre,
                TipoDocumento = tipoDocumento,
                NumDocumento = numDocumento,
                Direccion = direccion,
                Telefono = telefono,
                Email = email,
                Clave = clave
            };

            return datos.Actualizar(usuario);
        }// fin actualizar

        // Eliminar un usuario
        public static string Eliminar(int idUsuario)
        {
            dUsuario datos = new dUsuario();
            return datos.Eliminar(idUsuario);
        }// fin eliminar

        // Activar un usuario
        public static string Activar(int idUsuario)
        {
            dUsuario datos = new dUsuario();
            return datos.Activar(idUsuario);
        }// fin activar

        // Desactivar un usuario
        public static string Desactivar(int idUsuario)
        {
            dUsuario datos = new dUsuario();
            return datos.Desactivar(idUsuario);
        }// fin desactivar

        // METODO PARA LISTAR LOS ROLES
        public static DataTable ListarRol()
        {
            dRol datos = new dRol();
            return datos.Listar();
        }//fin listar
    }


}
