﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using sistema.Datos;

namespace sistema.Negocios
{
    public class NLogin
    {
        //metodo para login de usuario
        public static DataTable Login(string email, string clave)
        {
            dLogin datos = new dLogin();
            return datos.Login(email, clave);
        }   
    }
}
