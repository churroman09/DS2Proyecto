﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sistema.Entidad
{
    public class Articulo
    {
        public int IdArticulo { get; set; } // ID
        public int IdCategoria { get; set; } // idcategoria
        public string Categoria { get; set; } // Categoria
        public string Codigo { get; set; } // Codigo
        public string Nombre { get; set; } // Nombre
        public decimal PrecioVenta { get; set; } // Precio_Venta
        public int Stock { get; set; } // Stock
        public string Descripcion { get; set; } // Descripcion
        public string Imagen { get; set; } // Imagen
        public bool Estado { get; set; } // Estado
    }
}
