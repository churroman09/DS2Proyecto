﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sistema.Datos
{
    public class dRol
    {
        public DataTable Listar()
        {
            //para poder traer la data se neceseita un objeto de tipo DataReader

            SqlDataReader Resultado;

            //como necesitamos retornar un data table vamos a crear un objeto

            DataTable Tabla = new DataTable();
            //necesitamos un objeto que nos permite conectarnos a la base de datos
            SqlConnection sqlConnection = new SqlConnection();
            try
            {
                //obtener cadena de conexion
                sqlConnection = conexion.getInstancia().CrearConexion();
                //necesitamos
                SqlCommand Comando = new SqlCommand("rol_listar", sqlConnection);
                //indicar que es un procedimiento almacenado
                Comando.CommandType = CommandType.StoredProcedure;
                //abrir la conexion
                sqlConnection.Open();
                //ejecutar el comando
                Resultado = Comando.ExecuteReader();
                //como no podemos trabajar directamente con el data reader lo convertimos a un data table
                Tabla.Load(Resultado);
                //retornamos la tabla
                return Tabla;
            }
            catch (Exception ex)
            {

                throw ex;
            }
            finally
            {
                if (sqlConnection.State == ConnectionState.Open)
                {
                    sqlConnection.Close();
                }
            }

        }
    }
}
