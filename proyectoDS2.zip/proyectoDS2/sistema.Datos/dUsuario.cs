﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using sistema.Entidad;

namespace sistema.Datos
{
    public class dUsuario
    {
        public DataTable Listar()
        {
            SqlDataReader Resultado;
            DataTable Tabla = new DataTable();
            SqlConnection sqlConnection = new SqlConnection();

            try
            {
                sqlConnection = conexion.getInstancia().CrearConexion();
                SqlCommand Comando = new SqlCommand("usuario_listar", sqlConnection);
                Comando.CommandType = CommandType.StoredProcedure;
                sqlConnection.Open();
                Resultado = Comando.ExecuteReader();
                Tabla.Load(Resultado);
                return Tabla;
            }
            catch (Exception ex)
            {
                throw new Exception("Error al listar usuarios: " + ex.Message);
            }
            finally
            {
                if (sqlConnection.State == ConnectionState.Open)
                {
                    sqlConnection.Close();
                }
            }
        }

        public DataTable Buscar(string valor)
        {
            SqlDataReader resultado;
            DataTable tabla = new DataTable();
            SqlConnection sqlConnection = new SqlConnection();

            try
            {
                sqlConnection = conexion.getInstancia().CrearConexion();
                SqlCommand comando = new SqlCommand("usuario_buscar", sqlConnection);
                comando.CommandType = CommandType.StoredProcedure;
                comando.Parameters.AddWithValue("@valor", valor);
                sqlConnection.Open();
                resultado = comando.ExecuteReader();
                tabla.Load(resultado);
                return tabla;
            }
            catch (Exception ex)
            {
                throw new Exception("Error al buscar usuario: " + ex.Message);
            }
            finally
            {
                if (sqlConnection.State == ConnectionState.Open)
                {
                    sqlConnection.Close();
                }
            }
        }

        public string Insertar(Usuario usuario)
        {
            SqlConnection sqlConnection = new SqlConnection();

            try
            {
                sqlConnection = conexion.getInstancia().CrearConexion();
                SqlCommand comando = new SqlCommand("usuario_insertar", sqlConnection);
                comando.CommandType = CommandType.StoredProcedure;
                comando.Parameters.AddWithValue("@idrol", usuario.IdRol);
                comando.Parameters.AddWithValue("@nombre", usuario.Nombre);
                comando.Parameters.AddWithValue("@tipo_documento", usuario.TipoDocumento);
                comando.Parameters.AddWithValue("@num_documento", usuario.NumDocumento);
                comando.Parameters.AddWithValue("@direccion", usuario.Direccion);
                comando.Parameters.AddWithValue("@telefono", usuario.Telefono);
                comando.Parameters.AddWithValue("@email", usuario.Email);
                comando.Parameters.AddWithValue("@clave", usuario.Clave);

                sqlConnection.Open();
                int filasAfectadas = comando.ExecuteNonQuery();
                return filasAfectadas > 0 ? "Usuario registrado correctamente." : "Error al registrar el usuario.";
            }
            catch (Exception ex)
            {
                return "Error: " + ex.Message;
            }
            finally
            {
                if (sqlConnection.State == ConnectionState.Open)
                {
                    sqlConnection.Close();
                }
            }
        }

        public string Actualizar(Usuario usuario)
        {
            SqlConnection sqlConnection = new SqlConnection();

            try
            {
                sqlConnection = conexion.getInstancia().CrearConexion();
                SqlCommand comando = new SqlCommand("usuario_actualizar", sqlConnection);
                comando.CommandType = CommandType.StoredProcedure;
                comando.Parameters.AddWithValue("@idusuario", usuario.IdUsuario);
                comando.Parameters.AddWithValue("@idrol", usuario.IdRol);
                comando.Parameters.AddWithValue("@nombre", usuario.Nombre);
                comando.Parameters.AddWithValue("@tipo_documento", usuario.TipoDocumento);
                comando.Parameters.AddWithValue("@num_documento", usuario.NumDocumento);
                comando.Parameters.AddWithValue("@direccion", usuario.Direccion);
                comando.Parameters.AddWithValue("@telefono", usuario.Telefono);
                comando.Parameters.AddWithValue("@email", usuario.Email);
                comando.Parameters.AddWithValue("@clave", usuario.Clave);

                sqlConnection.Open();
                int filasAfectadas = comando.ExecuteNonQuery();
                return filasAfectadas > 0 ? "Usuario actualizado correctamente." : "Error al actualizar el usuario.";
            }
            catch (Exception ex)
            {
                return "Error: " + ex.Message;
            }
            finally
            {
                if (sqlConnection.State == ConnectionState.Open)
                {
                    sqlConnection.Close();
                }
            }
        }

        public string Eliminar(int idUsuario)
        {
            SqlConnection sqlConnection = new SqlConnection();

            try
            {
                sqlConnection = conexion.getInstancia().CrearConexion();
                SqlCommand comando = new SqlCommand("usuario_eliminar", sqlConnection);
                comando.CommandType = CommandType.StoredProcedure;
                comando.Parameters.AddWithValue("@idusuario", idUsuario);

                sqlConnection.Open();
                int filasAfectadas = comando.ExecuteNonQuery();
                return filasAfectadas > 0 ? "Usuario eliminado correctamente." : "Error al eliminar el usuario.";
            }
            catch (Exception ex)
            {
                return "Error: " + ex.Message;
            }
            finally
            {
                if (sqlConnection.State == ConnectionState.Open)
                {
                    sqlConnection.Close();
                }
            }
        }

        public string Activar(int idUsuario)
        {
            SqlConnection sqlConnection = new SqlConnection();

            try
            {
                sqlConnection = conexion.getInstancia().CrearConexion();
                SqlCommand comando = new SqlCommand("usuario_activar", sqlConnection);
                comando.CommandType = CommandType.StoredProcedure;
                comando.Parameters.AddWithValue("@idusuario", idUsuario);

                sqlConnection.Open();
                int filasAfectadas = comando.ExecuteNonQuery();
                return filasAfectadas > 0 ? "Usuario activado correctamente." : "Error al activar el usuario.";
            }
            catch (Exception ex)
            {
                return "Error: " + ex.Message;
            }
            finally
            {
                if (sqlConnection.State == ConnectionState.Open)
                {
                    sqlConnection.Close();
                }
            }
        }

        public string Desactivar(int idUsuario)
        {
            SqlConnection sqlConnection = new SqlConnection();

            try
            {
                sqlConnection = conexion.getInstancia().CrearConexion();
                SqlCommand comando = new SqlCommand("usuario_desactivar", sqlConnection);
                comando.CommandType = CommandType.StoredProcedure;
                comando.Parameters.AddWithValue("@idusuario", idUsuario);

                sqlConnection.Open();
                int filasAfectadas = comando.ExecuteNonQuery();
                return filasAfectadas > 0 ? "Usuario desactivado correctamente." : "Error al desactivar el usuario.";
            }
            catch (Exception ex)
            {
                return "Error: " + ex.Message;
            }
            finally
            {
                if (sqlConnection.State == ConnectionState.Open)
                {
                    sqlConnection.Close();
                }
            }
        }

        public string Existe(string email)
        {
            SqlConnection sqlConnection = new SqlConnection();

            try
            {
                sqlConnection = conexion.getInstancia().CrearConexion();
                SqlCommand comando = new SqlCommand("usuario_existe", sqlConnection);
                comando.CommandType = CommandType.StoredProcedure;
                comando.Parameters.AddWithValue("@valor", email);

                SqlParameter existeParam = new SqlParameter("@existe", SqlDbType.Bit)
                {
                    Direction = ParameterDirection.Output
                };
                comando.Parameters.Add(existeParam);

                sqlConnection.Open();
                comando.ExecuteNonQuery();

                return Convert.ToBoolean(existeParam.Value) ? "El usuario existe." : "El usuario no existe.";
            }
            catch (Exception ex)
            {
                return "Error: " + ex.Message;
            }
            finally
            {
                if (sqlConnection.State == ConnectionState.Open)
                {
                    sqlConnection.Close();
                }
            }
        }
    }
}