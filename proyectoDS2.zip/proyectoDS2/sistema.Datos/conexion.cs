﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace sistema.Datos
{
    internal class conexion
    {
        //parametros para conectarnos a la base de datos

        private string Base;//base de datos
        private string Servidor;//servidor
        private string Usuario;//usuario que se va a conectar
        private string Clave;//contraseña
        private bool seguridad;//indica si nos conectamos con estandard security o no
        private static conexion con = null;

        private conexion()
        {
            this.Base = "master";
            this.Servidor = "win\\SQLEXPRESS";
            this.Usuario = "sa";
            this.Clave = "";
            this.seguridad = true;
        }

        //metodo para poder crear una cadena de conexion
        public SqlConnection CrearConexion()
        {
            SqlConnection Cadena = new SqlConnection();
            try
            {
                Cadena.ConnectionString = "Server=" + this.Servidor + ";Database=" + this.Base + ";";
                if (this.seguridad)
                {
                    Cadena.ConnectionString = Cadena.ConnectionString + "Integrated Security = SSPI";
                }
                else
                {
                    Cadena.ConnectionString = Cadena.ConnectionString + "User Id=" + this.Usuario + ";Password=" + this.Clave;
                }
            } 
            catch (Exception ex)
            {
                Cadena = null;
                throw ex;
            }
            return Cadena;

        }



        //queremos que esta clase no puedan ser manipuladas
        //haremos un singleton
        public static conexion getInstancia()
        {
            if (con == null)
            {
                con = new conexion();
            }
            return con;
        }
    }




}
