﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using sistema.Entidad;

namespace sistema.Datos
{
    public class dCategorias
    {
        // listar las categorias que haya en la base de datos
        public DataTable Listar()
        {
            //para poder traer la data se neceseita un objeto de tipo DataReader

            SqlDataReader Resultado;

            //como necesitamos retornar un data table vamos a crear un objeto

            DataTable Tabla = new DataTable();
            //necesitamos un objeto que nos permite conectarnos a la base de datos
            SqlConnection sqlConnection = new SqlConnection();
            try
            {
                //obtener cadena de conexion
                sqlConnection = conexion.getInstancia().CrearConexion();
                //necesitamos
                SqlCommand Comando = new SqlCommand("categoria_listar", sqlConnection);
                //indicar que es un procedimiento almacenado
                Comando.CommandType = CommandType.StoredProcedure;
                //abrir la conexion
                sqlConnection.Open();
                //ejecutar el comando
                Resultado = Comando.ExecuteReader();
                //como no podemos trabajar directamente con el data reader lo convertimos a un data table
                Tabla.Load(Resultado);
                //retornamos la tabla
                return Tabla;
            }
            catch (Exception ex)
            {

                throw ex;
            }
            finally
            {
                if (sqlConnection.State == ConnectionState.Open)
                {
                    sqlConnection.Close();
                }
            }

        }
        //fin del metodo listar
        public DataTable Buscar(string valor)
        {
            // creamos un objeto sql data reader
            SqlDataReader Resultado;
            // creamos un Data table
            DataTable Tabla = new DataTable();
            //creamos sql connection
            SqlConnection sqlConnection = new SqlConnection();

            try
            {
                sqlConnection = conexion.getInstancia().CrearConexion();
                //creamos comando
                SqlCommand Comando = new SqlCommand("categoria_buscar", sqlConnection);
                Comando.CommandType = CommandType.StoredProcedure;
                //agregamos parametros
                Comando.Parameters.Add("@valor", SqlDbType.VarChar).Value = valor;
                //abrimos conexion
                sqlConnection.Open();
                //ejecutamos el comando
                Resultado = Comando.ExecuteReader();
                //cargamos el resultado en la tabla
                Tabla.Load(Resultado);
                return Tabla;
            }
            catch (Exception ex)
            {

                throw ex;
            }
            finally
            {
                if (sqlConnection.State == ConnectionState.Open)
                {
                    sqlConnection.Close();
                }
            }
        }//fin del metodo buscar

        public string Insertar(Categoria categoria)
        {
            //creamos un objeto sql connection
            SqlConnection sqlConnection = new SqlConnection();
            
            //creamos un string para almacenar el resultado
            string respuesta = "";
            try
            {
                //obtenemos la cadena de conexion
                sqlConnection = conexion.getInstancia().CrearConexion();
                //creamos un objeto sql command
                SqlCommand Comando = new SqlCommand("categoria_insertar", sqlConnection);
                //indicamos que es un procedimiento almacenado
                Comando.CommandType = CommandType.StoredProcedure;
                //indicamos el nombre del procedimiento almacenado
                Comando.CommandText = "categoria_insertar";
                //indicamos la conexion
                Comando.Connection = sqlConnection;
                //agregamos los parametros que requiere el procedimiento almacenado
                Comando.Parameters.Add("@nombre", SqlDbType.VarChar).Value = categoria.Nombre;
                Comando.Parameters.Add("@descripcion", SqlDbType.VarChar).Value = categoria.Descripcion;
                //abrimos la conexion
                sqlConnection.Open();
                //ejecutamos el comando
                respuesta = Comando.ExecuteNonQuery() == 1 ? "Categoria registrada" : "Error al registrar la categoria";
            }
            catch (Exception ex)
            {
                respuesta = ex.Message;
            }
            finally
            {
                if (sqlConnection.State == ConnectionState.Open)
                {
                    sqlConnection.Close();
                }
            }
            return respuesta;

        }//fin del metodo insertar


        public string Actualizar(Categoria categoria)
        {
            //creamos un objeto sql connection
            SqlConnection sqlConnection = new SqlConnection();

            //creamos un string para almacenar el resultado
            string respuesta = "";
            try
            {
                //obtenemos la cadena de conexion
                sqlConnection = conexion.getInstancia().CrearConexion();
                //creamos un objeto sql command
                SqlCommand Comando = new SqlCommand("categoria_actualizar", sqlConnection);
                //indicamos que es un procedimiento almacenado
                Comando.CommandType = CommandType.StoredProcedure;
                //indicamos la conexion
                Comando.Connection = sqlConnection;
                //agregamos los parametros que requiere el procedimiento almacenado
                Comando.Parameters.Add("@idcategoria", SqlDbType.Int).Value = categoria.IdCategoria;
                Comando.Parameters.Add("@nombre", SqlDbType.VarChar).Value = categoria.Nombre;
                Comando.Parameters.Add("@descripcion", SqlDbType.VarChar).Value = categoria.Descripcion;
                //abrimos la conexion
                sqlConnection.Open();
                //ejecutamos el comando
                respuesta = Comando.ExecuteNonQuery() == 1 ? "Categoria registrada" : "Error al registrar la categoria";
            }
            catch (Exception ex)
            {
                respuesta = ex.Message;
            }
            finally
            {
                if (sqlConnection.State == ConnectionState.Open)
                {
                    sqlConnection.Close();
                }
            }
            return respuesta;

        }//fin del metodo Actualizar

        //eliminar categoria
        public string Eliminar(int id)
        {
            //creamos un objeto sql connection
            SqlConnection sqlConnection = new SqlConnection();
            //creamos un string para almacenar el resultado
            string respuesta = "";
            try
            {
                //obtenemos la cadena de conexion
                sqlConnection = conexion.getInstancia().CrearConexion();
                //creamos un objeto sql command
                SqlCommand Comando = new SqlCommand("categoria_eliminar", sqlConnection);
                //indicamos que es un procedimiento almacenado
                Comando.CommandType = CommandType.StoredProcedure;
                //indicamos la conexion
                Comando.Connection = sqlConnection;
                //agregamos los parametros que requiere el procedimiento almacenado
                Comando.Parameters.Add("@idcategoria", SqlDbType.Int).Value = id;
                //abrimos la conexion
                sqlConnection.Open();
                //ejecutamos el comando
                respuesta = Comando.ExecuteNonQuery() >= 1 ? "Categoria eliminada" : "Error al eliminar la categoria";
            }
            catch (Exception ex)
            {
                respuesta = ex.Message;
            }
            finally
            {
                if (sqlConnection.State == ConnectionState.Open)
                {
                    sqlConnection.Close();
                }
            }
            return respuesta;
        }//fin del metodo eliminar

        public string Activar(int id)
        {
            //creamos un objeto sql connection
            SqlConnection sqlConnection = new SqlConnection();
            //creamos un string para almacenar el resultado
            string respuesta = "";
            try
            {
                //obtenemos la cadena de conexion
                sqlConnection = conexion.getInstancia().CrearConexion();
                //creamos un objeto sql command
                SqlCommand Comando = new SqlCommand("categoria_activar", sqlConnection);
                //indicamos que es un procedimiento almacenado
                Comando.CommandType = CommandType.StoredProcedure;
                //indicamos la conexion
                Comando.Connection = sqlConnection;
                //agregamos los parametros que requiere el procedimiento almacenado
                Comando.Parameters.Add("@idcategoria", SqlDbType.Int).Value = id;
                //abrimos la conexion
                sqlConnection.Open();
                //ejecutamos el comando
                respuesta = Comando.ExecuteNonQuery() >= 1 ? "Categoria activada" : "Error al activar la categoria";
            }
            catch (Exception ex)
            {
                respuesta = ex.Message;
            }
            finally
            {
                if (sqlConnection.State == ConnectionState.Open)
                {
                    sqlConnection.Close();
                }
            }
            return respuesta;
        }//fin del metodo activar

        public string Desactivar(int id)
        {
            //creamos un objeto sql connection
            SqlConnection sqlConnection = new SqlConnection();
            //creamos un string para almacenar el resultado
            string respuesta = "";
            try
            {
                //obtenemos la cadena de conexion
                sqlConnection = conexion.getInstancia().CrearConexion();
                //creamos un objeto sql command
                SqlCommand Comando = new SqlCommand("categoria_desactivar", sqlConnection);
                //indicamos que es un procedimiento almacenado
                Comando.CommandType = CommandType.StoredProcedure;
                //indicamos la conexion
                Comando.Connection = sqlConnection;
                //agregamos los parametros que requiere el procedimiento almacenado
                Comando.Parameters.Add("@idcategoria", SqlDbType.Int).Value = id;
                //abrimos la conexion
                sqlConnection.Open();
                //ejecutamos el comando
                respuesta = Comando.ExecuteNonQuery() >= 1 ? "Categoria desactivar" : "Error al desactivar la categoria";
            }
            catch (Exception ex)
            {
                respuesta = ex.Message;
            }
            finally
            {
                if (sqlConnection.State == ConnectionState.Open)
                {
                    sqlConnection.Close();
                }
            }
            return respuesta;
        }//fin del metodo desactivar
    }
}