﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using sistema.Entidad;

namespace sistema.Datos
{
    public class dArticulos
    {
        // Método para listar artículos
        public DataTable Listar()
        {
            SqlDataReader Resultado;
            DataTable Tabla = new DataTable();
            SqlConnection sqlConnection = new SqlConnection();

            try
            {
                sqlConnection = conexion.getInstancia().CrearConexion();
                SqlCommand Comando = new SqlCommand("articulo_listar", sqlConnection);
                Comando.CommandType = CommandType.StoredProcedure;
                sqlConnection.Open();
                Resultado = Comando.ExecuteReader();
                Tabla.Load(Resultado);
                return Tabla;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (sqlConnection.State == ConnectionState.Open)
                {
                    sqlConnection.Close();
                }
            }
        }

        // Método para buscar artículos
        public DataTable Buscar(string valor)
        {
            SqlDataReader Resultado;
            DataTable Tabla = new DataTable();
            SqlConnection sqlConnection = new SqlConnection();

            try
            {
                sqlConnection = conexion.getInstancia().CrearConexion();
                SqlCommand Comando = new SqlCommand("articulo_buscar", sqlConnection);
                Comando.CommandType = CommandType.StoredProcedure;
                Comando.Parameters.Add("@valor", SqlDbType.VarChar).Value = valor;
                sqlConnection.Open();
                Resultado = Comando.ExecuteReader();
                Tabla.Load(Resultado);
                return Tabla;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (sqlConnection.State == ConnectionState.Open)
                {
                    sqlConnection.Close();
                }
            }
        }

        // Método para insertar un artículo
        public string Insertar(Articulo articulo)
        {
            SqlConnection sqlConnection = new SqlConnection();
            string respuesta = "";

            try
            {
                sqlConnection = conexion.getInstancia().CrearConexion();
                SqlCommand Comando = new SqlCommand("articulo_insertar", sqlConnection);
                Comando.CommandType = CommandType.StoredProcedure;
                Comando.Parameters.Add("@idcategoria", SqlDbType.Int).Value = articulo.IdCategoria;
                Comando.Parameters.Add("@codigo", SqlDbType.VarChar).Value = articulo.Codigo;
                Comando.Parameters.Add("@nombre", SqlDbType.VarChar).Value = articulo.Nombre;
                Comando.Parameters.Add("@precio_venta", SqlDbType.Decimal).Value = articulo.PrecioVenta;
                Comando.Parameters.Add("@stock", SqlDbType.Int).Value = articulo.Stock;
                Comando.Parameters.Add("@descripcion", SqlDbType.VarChar).Value = articulo.Descripcion;
                Comando.Parameters.Add("@imagen", SqlDbType.VarChar).Value = articulo.Imagen;
                sqlConnection.Open();
                respuesta = Comando.ExecuteNonQuery() == 1 ? "Artículo registrado" : "Error al registrar el artículo";
            }
            catch (Exception ex)
            {
                respuesta = ex.Message;
            }
            finally
            {
                if (sqlConnection.State == ConnectionState.Open)
                {
                    sqlConnection.Close();
                }
            }
            return respuesta;
        }

        // Método para actualizar un artículo
        public string Actualizar(Articulo articulo)
        {
            SqlConnection sqlConnection = new SqlConnection();
            string respuesta = "";

            try
            {
                sqlConnection = conexion.getInstancia().CrearConexion();
                SqlCommand Comando = new SqlCommand("articulo_actualizar", sqlConnection);
                Comando.CommandType = CommandType.StoredProcedure;
                Comando.Parameters.Add("@idarticulo", SqlDbType.Int).Value = articulo.IdArticulo;
                Comando.Parameters.Add("@idcategoria", SqlDbType.Int).Value = articulo.IdCategoria;
                Comando.Parameters.Add("@codigo", SqlDbType.VarChar).Value = articulo.Codigo;
                Comando.Parameters.Add("@nombre", SqlDbType.VarChar).Value = articulo.Nombre;
                Comando.Parameters.Add("@precio_venta", SqlDbType.Decimal).Value = articulo.PrecioVenta;
                Comando.Parameters.Add("@stock", SqlDbType.Int).Value = articulo.Stock;
                Comando.Parameters.Add("@descripcion", SqlDbType.VarChar).Value = articulo.Descripcion;
                Comando.Parameters.Add("@imagen", SqlDbType.VarChar).Value = articulo.Imagen;
                sqlConnection.Open();
                respuesta = Comando.ExecuteNonQuery() == 1 ? "Artículo actualizado" : "Error al actualizar el artículo";
            }
            catch (Exception ex)
            {
                respuesta = ex.Message;
            }
            finally
            {
                if (sqlConnection.State == ConnectionState.Open)
                {
                    sqlConnection.Close();
                }
            }
            return respuesta;
        }

        // Método para eliminar un artículo
        public string Eliminar(int idArticulo)
        {
            SqlConnection sqlConnection = new SqlConnection();
            string respuesta = "";

            try
            {
                sqlConnection = conexion.getInstancia().CrearConexion();
                SqlCommand Comando = new SqlCommand("articulo_eliminar", sqlConnection);
                Comando.CommandType = CommandType.StoredProcedure;
                Comando.Parameters.Add("@idarticulo", SqlDbType.Int).Value = idArticulo;
                sqlConnection.Open();
                respuesta = Comando.ExecuteNonQuery() == 1 ? "Artículo eliminado" : "Error al eliminar el artículo";
            }
            catch (Exception ex)
            {
                respuesta = ex.Message;
            }
            finally
            {
                if (sqlConnection.State == ConnectionState.Open)
                {
                    sqlConnection.Close();
                }
            }
            return respuesta;
        }

        // Método para desactivar un artículo
        public string Desactivar(int idArticulo)
        {
            SqlConnection sqlConnection = new SqlConnection();
            string respuesta = "";

            try
            {
                sqlConnection = conexion.getInstancia().CrearConexion();
                SqlCommand Comando = new SqlCommand("articulo_desactivar", sqlConnection);
                Comando.CommandType = CommandType.StoredProcedure;
                Comando.Parameters.Add("@idarticulo", SqlDbType.Int).Value = idArticulo;
                sqlConnection.Open();
                respuesta = Comando.ExecuteNonQuery() == 1 ? "Artículo desactivado" : "Error al desactivar el artículo";
            }
            catch (Exception ex)
            {
                respuesta = ex.Message;
            }
            finally
            {
                if (sqlConnection.State == ConnectionState.Open)
                {
                    sqlConnection.Close();
                }
            }
            return respuesta;
        }

        // Método para activar un artículo
        public string Activar(int idArticulo)
        {
            SqlConnection sqlConnection = new SqlConnection();
            string respuesta = "";

            try
            {
                sqlConnection = conexion.getInstancia().CrearConexion();
                SqlCommand Comando = new SqlCommand("articulo_activar", sqlConnection);
                Comando.CommandType = CommandType.StoredProcedure;
                Comando.Parameters.Add("@idarticulo", SqlDbType.Int).Value = idArticulo;
                sqlConnection.Open();
                respuesta = Comando.ExecuteNonQuery() == 1 ? "Artículo activado" : "Error al activar el artículo";
            }
            catch (Exception ex)
            {
                respuesta = ex.Message;
            }
            finally
            {
                if (sqlConnection.State == ConnectionState.Open)
                {
                    sqlConnection.Close();
                }
            }
            return respuesta;
        }

        // Método para verificar si un artículo existe
        public bool Existe(string valor)
        {
            SqlConnection sqlConnection = new SqlConnection();
            bool existe = false;

            try
            {
                sqlConnection = conexion.getInstancia().CrearConexion();
                SqlCommand Comando = new SqlCommand("articulo_existe", sqlConnection);
                Comando.CommandType = CommandType.StoredProcedure;
                Comando.Parameters.Add("@valor", SqlDbType.VarChar).Value = valor;
                Comando.Parameters.Add("@existe", SqlDbType.Bit).Direction = ParameterDirection.Output;
                sqlConnection.Open();
                Comando.ExecuteNonQuery();
                existe = Convert.ToBoolean(Comando.Parameters["@existe"].Value);
            }
            catch (Exception)
            {
                throw;
            }
            finally
            {
                if (sqlConnection.State == ConnectionState.Open)
                {
                    sqlConnection.Close();
                }
            }
            return existe;
        }

        // Método para seleccionar categorías activas
        public DataTable SeleccionarCategorias()
        {
            SqlDataReader Resultado;
            DataTable Tabla = new DataTable();
            SqlConnection sqlConnection = new SqlConnection();

            try
            {
                sqlConnection = conexion.getInstancia().CrearConexion();
                SqlCommand Comando = new SqlCommand("categoria_seleccionar", sqlConnection);
                Comando.CommandType = CommandType.StoredProcedure;
                sqlConnection.Open();
                Resultado = Comando.ExecuteReader();
                Tabla.Load(Resultado);
                return Tabla;
            }
            catch (Exception ex)
            {
                throw ex;
            }
            finally
            {
                if (sqlConnection.State == ConnectionState.Open)
                {
                    sqlConnection.Close();
                }
            }
        }
    }
}

